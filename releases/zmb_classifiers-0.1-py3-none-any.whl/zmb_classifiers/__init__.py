# Inicialização do pacote zmb
